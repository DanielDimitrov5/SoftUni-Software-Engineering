﻿namespace P01_StudentSystem.Data.Models
{
    public enum ResourceTypes
    {
        Video = 1,
        Presentation = 1,
        Document = 2,
        Other = 3
    }
}