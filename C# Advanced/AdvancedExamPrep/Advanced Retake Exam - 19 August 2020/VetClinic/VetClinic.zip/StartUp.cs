﻿using System;
using VetClinic.Models;

namespace VetClinic
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            // Initialize the repository
            Clinic clinic = new Clinic(20);

            Console.WriteLine(clinic.GetPet("kuncho", "petio"));

        }
    }
}
