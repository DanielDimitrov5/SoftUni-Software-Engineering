﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataModifier
{
    public class DataMadifier
    {
        public DataMadifier(string startData, string endData)
        {
            StartData = startData;
            EndData = endData;
        }

        public string StartData { get; set; }
        public string EndData { get; set; }

        public int DiffCalcularor(string startData, string endData)
        {
            string[] dataASplited = startData.Split();

            int yearA = int.Parse(dataASplited[0]);
            int monthA = int.Parse(dataASplited[1]);
            int dayA = int.Parse(dataASplited[2]);

            DateTime A = new DateTime(yearA, monthA, dayA);

            string[] dataBSplited = endData.Split();

            int yearB = int.Parse(dataBSplited[0]);
            int monthB = int.Parse(dataBSplited[1]);
            int dayB = int.Parse(dataBSplited[2]);

            DateTime B = new DateTime(yearB, monthB, dayB);

            int dayDiff = Math.Abs((A - B).Days);

            return dayDiff;
        }
    }
}
