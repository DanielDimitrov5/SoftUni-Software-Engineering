﻿using System;

namespace DataModifier
{
    public class Program
    {
        static void Main(string[] args)
        {
            string firstDate = Console.ReadLine();
            string secondDate = Console.ReadLine();

            DataMadifier data = new DataMadifier(firstDate, secondDate);

            int diff = data.DiffCalcularor(firstDate, secondDate);

            Console.WriteLine(diff);
        }
    }
}
