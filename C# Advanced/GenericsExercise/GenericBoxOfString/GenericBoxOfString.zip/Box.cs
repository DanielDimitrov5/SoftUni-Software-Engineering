﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericBoxOfString
{
    public class Box<T>
    {
        T type;
        public Box(T type)
        {
            this.type = type;
        }

        public override string ToString()
        {
            return $"{type.GetType()}: {type}";
        }
    }
}
