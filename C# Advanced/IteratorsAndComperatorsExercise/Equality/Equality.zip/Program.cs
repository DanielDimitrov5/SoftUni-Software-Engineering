﻿using System;
using System.Collections.Generic;

namespace IteratorsAndComeparators
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SortedSet<Person> sortedSet = new SortedSet<Person>();
            HashSet<Person> hashSet = new HashSet<Person>();

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] input = Console.ReadLine().Split();

                string name = input[0];
                int age = int.Parse(input[1]);

                Person newPerson = new Person(name, age);

                sortedSet.Add(newPerson);
                hashSet.Add(newPerson);
            }

            Console.WriteLine(sortedSet.Count);
            Console.WriteLine(hashSet.Count);
        }
    }

    class Person : IComparable<Person>
    {
        public Person(string name, int age)
        {
            Name = name;
            Age = age;
        }

        public string Name { get; set; }
        public int Age { get; set; }

        public int CompareTo(Person other)
        {
            int result = Name.CompareTo(other.Name);

            if (result == 0)
            {
                result = Age.CompareTo(other.Age);
            }

            return result;
        }

        public override bool Equals(object obj)
        {
            Person person = (Person)obj;

            if ((obj == null) || !GetType().Equals(person.GetType()))
            {
                return false;
            }

            return Name == person.Name && Age == person.Age;
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode() / 3 + Age.GetHashCode() * 2;
        }
    }
}