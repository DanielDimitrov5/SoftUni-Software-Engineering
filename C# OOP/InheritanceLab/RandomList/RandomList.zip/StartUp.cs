﻿using System;
using System.Collections.Generic;

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            RandomList list = new RandomList(new List<string> { "1", "2", "3", "4", "5", "6", "71", "8", "9", "11" });

            Console.WriteLine(list.RandomString());
        }
    }
}
