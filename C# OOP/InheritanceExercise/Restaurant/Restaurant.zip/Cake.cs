﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Restaurant
{
    public class Cake : Dessert
    {
        private const double Grams = 250;
        private const double Calories = 100;
        private const decimal Price = 5m;

        public Cake(string name)
            : base(name, Price, Calories, Grams)
        {

        }
    }
}
