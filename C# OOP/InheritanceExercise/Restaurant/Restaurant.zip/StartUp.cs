﻿namespace Restaurant
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Coffee coffee = new Coffee("Late", 13.5);

            System.Console.WriteLine(coffee.Milliliters);

            Dessert fish = new Dessert("ivo", 12, 14, 16);
            System.Console.WriteLine(fish.Grams);
            Cake cake = new Cake("stamat");
            System.Console.WriteLine(cake.Calories);
        }
    }
}