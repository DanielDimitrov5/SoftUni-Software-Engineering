using NUnit.Framework;
using System;

namespace Tests
{
    public class WarriorTests
    {
        private const int MIN_ATTACK_HP = 30;

        private string name = "Ivo";
        private int damage = 70;
        private int hp = 100;

        private Warrior warrior;

        [SetUp]
        public void Setup()
        {
            warrior = new Warrior(name, damage, hp);
        }

        [Test]
        [TestCase(" ", 100, 100)]
        [TestCase("", 100, 100)]
        [TestCase(null, 100, 100)]
        [TestCase("Warrior", 0, 100)]
        [TestCase("Warrior", -1, 100)]
        [TestCase("Warrior", 100, -1)]
        public void CtorSetsAllPropertiesAndDoValidation(string name, int damage, int hp)
        {
            Assert.Throws<ArgumentException>(() => new Warrior(name, damage, hp));
        }

        [Test]
        [TestCase(30)]
        [TestCase(20)]
        public void AttackMethodThrowsAnExceptionWhenAttackersHpIsEqualOrLessThan_MIN_ATTACK_HP(int hp)
        {
            Warrior attacker = new Warrior(name, damage, hp);
            Warrior defender = new Warrior(name, damage, this.hp);

            Assert.Throws<InvalidOperationException>(() => attacker.Attack(defender));
        }

        [Test]
        [TestCase(30)]
        [TestCase(20)]
        public void AttackMethodThrowsAnExceptionWhenDefenderHpIsEqualOrLessThan_MIN_ATTACK_HP(int hp)
        {
            Warrior attacker = new Warrior(name, damage, this.hp);
            Warrior defender = new Warrior(name, damage, hp);

            Assert.Throws<InvalidOperationException>(() => attacker.Attack(defender));
        }


        [Test]
        public void AttackMethodThrowsAnExceptionsWhenAttackerHpIsLessThanTheDefenders()
        {
            Warrior warrior = new Warrior(name, damage, hp);
            Warrior defender = new Warrior(name, hp + 1, hp);

            Assert.That(() => warrior.Attack(defender),
                Throws.InvalidOperationException.With.Message.EqualTo("You are trying to attack too strong enemy"));
        }

        [Test]
        public void AttackMethodReducesAttackerHp()
        {
            Warrior warrior = new Warrior(name, 100, 100);
            Warrior defender = new Warrior(name, 50, 50);

            int expected = 100 - 50;

            warrior.Attack(defender);

            int actual = warrior.HP;

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void AttackMethodSetsDefendersHpToZeroWhen_AttackersDamageIsGreaterThanDefendersHp()
        {
            Warrior warrior = new Warrior(name, damage, hp);
            Warrior defender = new Warrior(name, damage, damage - 1);

            int expected = 0;

            warrior.Attack(defender);

            int actual = defender.HP;

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void AttackMethodReducesDefendersHp()
        {
            Warrior warrior = new Warrior(name, damage, hp);
            Warrior defender = new Warrior(name, damage, hp);

            int expected = defender.HP - warrior.Damage;

            warrior.Attack(defender);

            int actual = defender.HP;

            Assert.AreEqual(expected, actual);
        }
    }
}