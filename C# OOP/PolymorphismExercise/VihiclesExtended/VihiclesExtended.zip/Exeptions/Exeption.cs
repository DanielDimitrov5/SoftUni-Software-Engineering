﻿namespace VihiclesExtended.Exeptions
{
    public static class Exeption
    {
        public static string InvalidFuelAmount = "Fuel must be a positive number";
    }
}
