﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Contracts;

namespace WildFarm.Models.Foods
{
    public class Meat : Food
    {
        public Meat(int quantity)
            : base(quantity)
        { }
    }
}
