﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FootballTeam
{
    class Team
    {
        private List<Player> players;

        private string name;

        public Team(string name)
        {
            Name = name;
            players = new List<Player>();
        }

        public string Name
        {
            get => name;

            private set
            {
                if (string.IsNullOrEmpty(value) || string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("A name should not be empty.");
                }

                name = value;
            }
        }

        public void AddPlayer(Player player)
        {
            players.Add(player);
        }

        public void RemovePlayer(string player)
        {
            try
            {
                Player current = players.Where(x => x.Name == player).First();
                players.Remove(current);
            }
            catch (InvalidOperationException)
            {
                throw new ArgumentException($"Player {player} is not in {this.Name} team.");
            }
        }

        public void Rating()
        {
            int average = 0;

            if (players.Count != 0)
            {
                int sum = 0;

                foreach (var player in players)
                {
                    sum += player.OverallSkill();
                }

                average = (int)Math.Round(sum / players.Count * 1.0);
            }

            Console.WriteLine($"{name} - {average}");
        }
    }
}
