﻿namespace Cars
{
    public static class Messages
    {
        public const string StartEngine = "Engine start";

        public const string StopEngine = "Breaaak!";
    }
}
