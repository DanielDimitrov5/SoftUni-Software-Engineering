﻿using System;
namespace BirthdayCelebrations.Contaracts
{
    public interface IBirth
    {
        public DateTime Birthday { get; set; }
    }
}
