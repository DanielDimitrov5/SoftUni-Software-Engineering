﻿namespace BirthdayCelebrations.Contaracts
{
    public interface IIdentifiable
    {
        public string Id { get; }
    }
}
