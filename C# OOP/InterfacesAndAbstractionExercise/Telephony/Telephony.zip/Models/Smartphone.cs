﻿using System;
using System.Linq;
using Telephony1.Contracts;

namespace Telephony1.Models
{
    public class Smartphone : ICallable,  IBrowsable
    {
        public void Call(string phoneNumber)
        {
            if (phoneNumber.All(x => char.IsDigit(x)))
            {
                Console.WriteLine($"Calling... {phoneNumber}");
            }
            else
            {
                throw new ArgumentException("Invalid number!");
            }
        }

        public void Browse(string site)
        {
            if (site.Any(x => char.IsDigit(x)))
            {
                throw new ArgumentException("Invalid URL!");
            }

            Console.WriteLine($"Browsing: {site}!");
        }
    }
}
