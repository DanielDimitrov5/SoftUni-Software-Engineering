﻿using System;
using System.Linq;
using Telephony1.Contracts;

namespace Telephony1.Models
{
    public class StationaryPhone : ICallable
    {
        public void Call(string phoneNumber)
        {
            if (phoneNumber.All(x => char.IsDigit(x)))
            {
                Console.WriteLine($"Dialing... {phoneNumber}");
            }
            else
            {
                throw new ArgumentException("Invalid number!");
            }
        }
    }
}
