﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectionHierarchy.Contracts
{
    public interface IAdd
    {
        int Add(string text);
    }
}
