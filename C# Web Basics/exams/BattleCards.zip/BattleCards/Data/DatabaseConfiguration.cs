﻿namespace BattleCards.Data
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
            @"Server=.;Database=BattleCards;Trusted_Connection=True;Integrated Security=True;";
    }
}